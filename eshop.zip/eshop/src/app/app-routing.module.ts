import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from './access/services/authGuard/auth-guard.service';
import { CartComponent } from './site/components/cart/cart.component';
import { CheckoutComponent } from './site/components/checkout/checkout.component';
import { ErrorComponent } from './site/components/error/error.component';
import { LayoutComponent } from './site/components/layout/layout.component';
import { ListingComponent } from './site/components/listing/listing.component';
import { ProductDetailsComponent } from './site/components/product-details/product-details.component';
import { PurchaseComponent } from './site/components/purchase/purchase.component';

const routes: Routes = [
  {path:'', component: LayoutComponent, children: [
    {path:'', component: ListingComponent},
    {path:'cart', component: CartComponent, canActivate:[AuthGuardService]},
    {path:'checkout/:id', component: CheckoutComponent, canActivate:[AuthGuardService]},
    {path:'purchase', component: PurchaseComponent, canActivate:[AuthGuardService]},
    ]
  },
  {path:'detail', component: ProductDetailsComponent},
  // {path:'cart/:productId', component: CartComponent, canActivate:[AuthGuardService]},
  // {path:'cart', component: CartComponent, canActivate:[AuthGuardService]},
  // {path:'checkout/:id', component: CheckoutComponent, canActivate:[AuthGuardService]},
  // {path:'purchase', component: PurchaseComponent, canActivate:[AuthGuardService]},
  // {path:'admin', component: DefaultComponent},
  { path: 'admin', loadChildren:()=>import('src/app/admin/admin.module').then(i=>i.AdminModule), canActivate:[AuthGuardService] },
  { path: 'access', loadChildren:()=>import('src/app/access/access.module').then(i=>i.AccessModule) },
  {path:'**', component: ErrorComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

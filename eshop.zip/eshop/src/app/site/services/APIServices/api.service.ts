import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class APIService {

  constructor(private http: HttpClient) { }

  getDataFromHttp() {
    return this.http.get("http://localhost:8080/allProducts/");

  }

  getCartData(email) {
    return this.http.get("http://localhost:8080/cartProducts/"+email);

  }

  getCartProductData(email) {
    return this.http.get("http://localhost:8080/cart/"+email);

  }
  getCartDetails(cartid) {
    return this.http.get("http://localhost:8080/checkout/"+cartid.id);

  }

  saveCartData(obj) {
    console.log("saveCartData: ", obj)
    return this.http.post("http://localhost:8080/saveCart", obj);
  }

  purchase(obj) {
    return this.http.post("http://localhost:8080/purchase", obj);
  }
}

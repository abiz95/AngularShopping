import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/admin/services/product/product.service';
import { APIService } from '../../services/APIServices/api.service';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.scss']
})
export class ListingComponent implements OnInit, OnDestroy {

  productIdList = new Array(); 
  products
  sessionUser
  dataSub
  dataCart
  constructor(private apiService: APIService, private router: Router) { }

  ngOnInit(): void {
    this.dataSub = this.apiService.getDataFromHttp().subscribe(
      (res)=>{
        console.log("res: ",res)
        this.products=res
      });
  }

  addToCart(data) {
    console.log("listing data",data);
    this.sessionUser = sessionStorage.getItem('userName');
    console.log("session user",data.productId);
    this.productIdList.push(data.productId)
    console.log("product Id's",this.productIdList);
    // this.apiService.dataBus=data;
    this.dataCart = this.apiService.saveCartData({"email":this.sessionUser,"productId":data.productId,"qty":1}).subscribe(
      (res)=>{
        console.log("res: ",res)
      });
  //   this.router.navigate(['cart',data.productId])
  }

  ngOnDestroy() {
    if (this.dataSub) {
      console.log("unsubscribe")
        this.dataSub.unsubscribe();
    }
    if (this.dataCart) {
      console.log("unsubscribe")
        this.dataCart.unsubscribe();
    }
  }

}

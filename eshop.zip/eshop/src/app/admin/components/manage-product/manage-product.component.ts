import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../../services/product/product.service';

@Component({
  selector: 'app-manage-product',
  templateUrl: './manage-product.component.html',
  styleUrls: ['./manage-product.component.scss']
})
export class ManageProductComponent implements OnInit {

  productForm
  updateVal
  updateData
  dataSource

  constructor(
    private formBuilder: FormBuilder, 
    private router: Router, 
    private productService: ProductService,
    private route: ActivatedRoute,
    ) {
    this.route.params.subscribe( params => {
      console.log("param",params)
      this.updateVal=params;
    });
  }

  ngOnInit(): void {
    this.productForm =this.formBuilder.group(
        {
          productId: [],
          productName: ["", [Validators.required]],
          productDescription: ["", [Validators.required]],
          productPrice: ["", [Validators.required]],
        }
      );

      this.productService.getDataFromHttp().subscribe(
        (res)=>{
          console.log("res: ",res)
          this.dataSource=res
        });

      // if (this.updateVal) {
      //   this.productService.getProductFromHttp(this.updateVal).subscribe(
      //     (res)=>{
      //       this.updateData=res
      //       console.log("update res: ",this.updateData)
      //     });
      //   console.log("inside updateData", this.updateData);
      //   this.productForm.controls['productName'].setValue(this.updateData.productName);
      //   this.productForm.controls['productDescription'].setValue(this.updateData.productDescription);
      //   this.productForm.controls['productPrice'].setValue(this.updateData.productPrice);
      // }

      if (this.updateVal) {
        console.log("inside ngOnInit", this.updateVal);
        this.productForm.controls['productId'].setValue(this.updateVal.productId);
        this.productForm.controls['productName'].setValue(this.updateVal.productName);
        this.productForm.controls['productDescription'].setValue(this.updateVal.productDescription);
        this.productForm.controls['productPrice'].setValue(this.updateVal.productPrice);
      }
  }
  displayedColumns: string[] = ['productId', 'productName', 'productDescription', 'productPrice'];

  getData() {
    this.productService.getDataFromHttp().subscribe(
      (res)=>{
        console.log("res: ",res)
        this.dataSource=res
      });
  }

  get formValues() {
    return this.productForm.controls;
  }

  saveForm() {
    console.log("form data", this.productForm.value);

    if (this.productForm.valid) {
      console.log("updateVal: ", this.updateVal);
      if (this.updateVal.productName) {
        console.log("inside update", this.updateVal);
        this.productService.putProductFromHttp(this.productForm.value).subscribe(
          res => {
            console.log(res);
            this.getData();
            // this.router.navigate(['list'])
          }
        )
      } 
      else {
        console.log("inside save", this.updateVal);
        this.productService.postDataFromHttp(this.productForm.value).subscribe(
          res => {
            console.log(res);
            this.router.navigate(['admin/list'])
          }
        )
      }
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from 'src/app/access/services/authService/auth-service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  isUserLoggedIn
  constructor(private auth: AuthServiceService) { }

  ngOnInit(): void {
    this.isUserLoggedIn = this.auth.isUserLoggedIn();
  }

  logout() {
    this.auth.logout();
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceService } from '../../services/authService/auth-service.service';
import { CustomValidationService } from '../../services/customValidation/custom-validation.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  signupForm;
  hide = true;
  c_hide = true;
  
  constructor(
    private formBuilder: FormBuilder, 
    private router: Router, 
    private customValidator: CustomValidationService,
    private authService: AuthServiceService,
    ) {

  }

  ngOnInit(): void {
    this.signupForm =this.formBuilder.group(
        {
          email: ["", [Validators.required, Validators.email]],
          password: ["", Validators.compose([Validators.required, this.customValidator.patternValidator()])],
          confirmPassword: ["", [Validators.required]],
        },
        {
          validator: this.customValidator.MatchPassword('password', 'confirmPassword'),
        }
      );
  }

  get formValues() {
    return this.signupForm.controls;
  }

  firstName() {
    return this.signupForm.get('firstName');
  }

  saveForm() {
    console.log("form data", this.signupForm.value);
    // console.log("errors: ", this.signupForm.valid);
    // this.router.navigate(['login'])
    if (this.signupForm.valid) {
      console.log("password matched: ", this.signupForm.value);
      this.authService.saveUserData(this.signupForm.value).subscribe(
        res => {
          console.log(res);
          this.router.navigate([''])
        }
      )
    }
  }

  login() {
    this.router.navigate(['login'])
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from '../../services/APIServices/api.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  sessionUser = sessionStorage.getItem('userName');
  // productIdList = new Array(); 
  // productId
  qty
  productprice
  totalprice
  total
  dataCart
  dataSub
  productData
  productForm
  constructor(
    private formBuilder: FormBuilder, 
    private apiService: APIService, 
    private route: ActivatedRoute,
    private router: Router,
    ) {
    // this.route.params.subscribe( params => {
    //   console.log("param",params)
    //   this.productId=params;
    // });
  }

  ngOnInit(): void {

    this.productForm =this.formBuilder.group(
      {
        productId: [],
        productPrice: [],
        qty: ["", [Validators.required]],
      }
    );

    console.log("search",this.sessionUser);
    this.dataSub = this.apiService.getCartProductData(this.sessionUser).subscribe(
      (res)=>{
        console.log("cart res: ",res)
        this.productData=res
      });
      // this.productForm.controls['qty'].setValue(this.productData.qty);
      // console.log("qty: ",this.productForm.controls['qty'].get());
      // if (this.productData) {
      //   this.productForm.controls['qty'].setValue(this.productData.qty);
      //   console.log("qty: ",this.productForm.controls['qty'].get())
      // }
      // this.justDisplay();
  }

  get formValues() {
    return this.productForm.controls;
  }

  buy(data) {
    console.log("just: ",data)
    console.log("qty: ",this.productForm.get('qty').value);
    this.qty=this.productForm.get('qty').value;
    this.productprice = this.productForm.get('productPrice').value;
    console.log("price: ",data.productPrice)
    this.totalprice=data.productPrice*this.qty;
    console.log("total price: "+this.totalprice);

    console.log("buy data",this.productForm.value)
    this.dataCart = this.apiService.saveCartData({"email":this.sessionUser,"productId":data.productId,"qty":this.qty,"totalPrice":this.totalprice}).subscribe(
      (res)=>{
        console.log("save cart res: ",res)
      });
    this.router.navigate(['checkout',data.cartId])
  }

  ngOnDestroy() {
    if (this.dataSub) {
      console.log("unsubscribe")
        this.dataSub.unsubscribe();
    }
    if (this.dataCart) {
      console.log("unsubscribe")
        this.dataCart.unsubscribe();
    }
  }

}

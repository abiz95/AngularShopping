import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  getDataFromHttp() {
    return this.http.get("http://localhost:8080/allProducts/")

  }

  getProductFromHttp(id) {
    console.log("product id: ",id)
    return this.http.get("http://localhost:8080/products/"+id.id)

  }

  putProductFromHttp(obj:any) {
    return this.http.put('http://localhost:8080/updateProduct/', obj)
  }

  postDataFromHttp(obj:any) {
    return this.http.post('http://localhost:8080/saveProduct/', obj)
  }

  deleteDataFromHttp(id) {
    return this.http.delete('http://localhost:8080/delete/'+id)
  }
}

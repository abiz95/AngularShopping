import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceService } from '../../services/authService/auth-service.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  signinForm;
  hide = true;
  validationError:boolean=false
  errorInd:boolean=false

  constructor(
    private formBuilder: FormBuilder, 
    private router: Router,
    private authService: AuthServiceService,
    ) { }
 
  ngOnInit(): void {
    this.signinForm =this.formBuilder.group(
      {
        email: ["", [Validators.required]],
        password: ["", [Validators.required]],
      }
    );
  }
 
  get formValues() {
    return this.signinForm.controls;
  }
 
  saveForm() {
    console.log("form data", this.signinForm.value);
    // console.log("errors: ", this.signinForm.valid);
    // this.router.navigate(['login'])
    if (this.signinForm.valid) {
      console.log("password matched: ", this.signinForm.value);
      this.authService.userValidation(this.signinForm.value).subscribe(
        res => {
          console.log(res);
          // this.validation=res
          // console.log(this.validation[0]);
          this.router.navigate([''])
          if (res[0]==="success") {
            console.log("success completed");
            console.log("login User: ",this.signinForm.get('email').value);
            sessionStorage.setItem('userName',this.signinForm.get('email').value);
            this.router.navigate([''])
          }
          else {
            this.validationError=true;
          }
        },
        (err) => {
          if (err.status === 401) {
            this.validationError=true;
          }
          else {
            this.errorInd=true;
          }
          // console.error('error caught in component',err.status)
        }
      )
    }
  }
}

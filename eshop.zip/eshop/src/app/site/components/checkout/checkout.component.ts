import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from '../../services/APIServices/api.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {

  cartId
  cartData
  dataSub
  constructor(
    private apiService: APIService, 
    private route: ActivatedRoute,
    private router: Router,
  ) {
      this.route.params.subscribe( params => {
      console.log("param",params)
      this.cartId=params;
    });
  }

  ngOnInit(): void {
    this.dataSub = this.apiService.getCartDetails(this.cartId).subscribe(
      (res)=>{
        console.log("checkout res: ",res)
        this.cartData=res
      });
  }

  purchase() {
    console.log("purchase data: ",this.cartData)
    this.dataSub = this.apiService.purchase(this.cartData).subscribe(
      (res)=>{
        console.log("purchase res: ",res)
        this.cartData=res
        this.router.navigate(['purchase'])
      });
  }

}
